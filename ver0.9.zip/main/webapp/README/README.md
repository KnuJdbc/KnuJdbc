# KnuJdbc

main.html이 시작이고 테이블 row를 클릭하시면 자세한 정보가 출력됩니다.
